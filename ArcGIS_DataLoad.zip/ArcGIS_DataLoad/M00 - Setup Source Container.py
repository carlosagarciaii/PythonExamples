# Author: 	Carlos Garcia II
#	
#	This sscript is designed to batch project from one SDE
#	to another while removing Z & M Values.




import os,sys,arcpy,traceback,logging, datetime,subprocess


global vCoordinateSystem
global vSDEDBNameSource 
global vPostgresPW
global vSDEPW
global varcLicFilePath



# Configuration

vSDEDBNameSource = "countyName"
vPostgresPW = "AppXNPW"
vSDEPW = "AppXNPW"
varcLicFilePath = "C:/Users/cgarcia/Documents/_Python Scripts/esri_key.ecp"


vCoordinateSystem = "GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]"

#End Configuration





#Global Variables
global vWorkingDir
vWorkingDir = str(os.path.dirname(os.path.abspath(__file__)) + "/WorkingDir/").replace("\\","/")
global gvMessage
gvMessage = "" 


#Create Working Directory
if not os.path.exists(vWorkingDir):
	print "Output Directory Does Not Exist"
	os.makedirs(vWorkingDir)
else:
	print "Output Directory Exists"


#Logging Setup
logging.basicConfig(filename=vWorkingDir + os.path.basename(__file__) + '_diagnostic.log', format='%(asctime)s %(message)s', level=logging.DEBUG)
vLoggingSegmenter = "Closing Log\n\n________________________________________________________\n________________________________________________________\n\n"



def fnLogThis(vMessage):
	fnLogThis(vMessage)
	print vMessage
	
	
#Altering PGPass.conf to not require a password
def fAlterPGPass(fvPGDB):
	vMessage = "Altering pgpass.conf" 
	fnLogThis(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	fnLogThis("Updating:\t" + tPGPass)
	
	if not os.path.exists(tPGPass):
		fnLogThis("Does not Exist\t" + tPGPass)
		file = open(tPGPass,'w')
		
	else:
		fnLogThis( "Exists\t" + tPGPass)
		
		file = open(tPGPass,'w')
	tPGPasstxt = "localhost:5432:" + fvPGDB + ":postgres:" + vPostgresPW
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "Altered pgpass.conf to\t"  + tPGPasstxt + "\n"
	fnLogThis(vMessage)
	return 

	
#Altering PGPass.conf to not require a password
def fResetPGPass():
	vMessage = "Reseting pgpass.conf" 
	fnLogThis(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	fnLogThis( "Updating:\t" + tPGPass)
	
	if not os.path.exists(tPGPass):
		fnLogThis( "Does not Exist\t" + tPGPass)
		file = open(tPGPass,'w')
		
	else:
		fnLogThis( "Exists\t" + tPGPass)
		
		file = open(tPGPass,'w')
	tPGPasstxt = ""
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "pgpass.conf has been Reset\n"
	fnLogThis(vMessage)
	return 
	
	
#Creating  database
def fCreateDB(fvDBName):
	vMessage = "Creating Database:\t" +  fvDBName
	fnLogThis(vMessage)	
	
	os.system("psql -U postgres -w -c \"CREATE DATABASE " + fvDBName + "  WITH ENCODING='UTF8' OWNER=sde TEMPLATE=template_postgis_20 CONNECTION LIMIT=-1;\"")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created Database:\t" +  fvDBName + "\n"
	fnLogThis(vMessage)	
	return


#dropping database
def fDropDB(fvDBName):
	vMessage = "Dropping Database:\t" +  fvDBName
	fnLogThis(vMessage)	
	
	try:
		fSDEWorkSpaceRelease()
		fAlterPGPass("postgres")
		os.system("dropdb -U postgres -w " +  fvDBName)
	except Exception, fE:
		vMessage = "Database " +  fvDBName + " Does Not Exist\n"
		fnLogThis(vMessage)	
		
		fnLogThis(fE.message)
		tb = traceback.format_exc()
		fnLogThis("Extended Info:\n\t" + tb)
	
	vMessage = "Database Dropped:\t" +  fvDBName + "\n"
	fnLogThis(vMessage)	
	return	
	
	
#Create SDE Connection File
def fCreateSDEConnFile(fvDBName):
	vMessage = "Creating SDE Connection for:\t" +  fvDBName
	fnLogThis(vMessage)	
	
	ftSDEConnFile = vWorkingDir + fvDBName + ".sde"
	
	if os.path.exists(ftSDEConnFile):		
		fnLogThis( "Removing " + fvDBName + ".sde")
		os.remove(ftSDEConnFile)
	else:
		fnLogThis( "Creating " + fvDBName + ".sde")

	arcpy.CreateArcSDEConnectionFile_management(vWorkingDir, fvDBName + ".sde", "localhost", "sde:postgresql:localhost", fvDBName, "DATABASE_AUTH", "sde", vSDEPW,"SAVE_USERNAME","sde.DEFAULT","SAVE_VERSION")
			
			
	sdeConnFile = vWorkingDir + fvDBName + ".sde"
	
	fnLogThis("\nESRI Message:" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created SDE Connection for:\t" +  fvDBName + "\n"
	fnLogThis(vMessage)	
	return	
	
	
#Enable Enterprise GeoDatabase
def fEnableEntGDB(fvDBName):	
	global varcLicFilePath
	global vWorkingDir
	vSDEConnFile = vWorkingDir + fvDBName + ".sde"
	vMessage = "Enabling SDE on Database:\t" + fvDBName 
	fnLogThis(vMessage)	
	
	arcpy.EnableEnterpriseGeodatabase_management(vSDEConnFile,varcLicFilePath)	

	fnLogThis("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	vMessage = "Enabled SDE on Database:\t" + fvDBName + "\n"
	fnLogThis(vMessage)	
	return	
	
	
def fDisconnectUsers():

	global vSDEDBNameSource
	global vWorkingDir
	SDEConnFile1 = vWorkingDir + vSDEDBNameSource	
	
	print "Disconnecting from:\t" + SDEConnFile1
	try:
		arcpy.DisconnectUser(SDEConnFile1,"ALL")
	except:
		fnLogThis( SDEConnFile1 + " does not exist or is not a valid SDE")
	
	fSDEWorkSpaceRelease()
	
	return
	
	
def fSDEDBTune(fvDBName):
	global vPostgresPW
	global vSDEPW
	vMessage = "Setting Spatial Storage for:\t" +  fvDBName
	fnLogThis(vMessage)
	#sdedbtune -o alter -k DEFAULTS -P GEOMETRY_STORAGE -v PG_GEOMETRY -s 192.168.11.22 -D live -u sde -p AppXN1 -i sde:postgresql:192.168.11.22
	vOSExecute = "sdedbtune -o alter -k DEFAULTS -P GEOMETRY_STORAGE -v PG_GEOMETRY -s 127.0.0.1 -D " + fvDBName + " -u sde -p " + vSDEPW + " -i sde:postgresql:127.0.0.1 -N"
	fnLogThis( "Executing:\t" + vOSExecute)
	os.system(vOSExecute)	
	
	
	vMessage = "Spatial Storage Set for:\t" +  fvDBName + "\n\n"
	fnLogThis(vMessage)
	return

	
#Releasing Workspace/Locks	
def fSDEWorkSpaceRelease():		
	arcpy.env.workspace = ""
	arcpy.ClearWorkspaceCache_management()
	vMessage = "Workspace Release"
	fnLogThis(vMessage)
	return

	
#Set FeatureClass as Versioned	
def	fRegisterAsVersionedFC(fvDBName):
	print "\n\n"

	vMessage = "Registering Feature As Versioned\n___________________________________________________"
	fnLogThis(vMessage)
	
	fSDEWorkSpaceRelease()	
	global vWorkingDir
	global vTempDBName1
	global vCoordinateSystem
	
	sdeConnFile1 = vWorkingDir +  fvDBName + ".sde"
	
	arcpy.env.workspace = sdeConnFile1
	vLayers = arcpy.ListFeatureClasses() + arcpy.ListDatasets()
	
	fnLogThis("Starting Versioning Features")
	
	
	for x in range(0,len(vLayers)):
		
		if arcpy.Describe(vLayers[x]).isVersioned == False:
			fnLogThis( "Registering Version for:\t" + vLayers[x])
			arcpy.RegisterAsVersioned_management(vLayers[x])
			fnLogThis("ESRI Message:\n\t" + arcpy.GetMessages())
			fnLogThis( str(arcpy.GetMessages()) + "\n")
		else:
			fnLogThis("\tIs Versioned\t" + vLayers[x] )
	
	vMessage = "\n\tLayer Versioning Complete\n\n"
	fnLogThis(vMessage)
	fSDEWorkSpaceRelease()
	return

	
def fnColor(fStatus):	
	print "\n\n"

	if fStatus == 1: #Standby;
		os.system("color 0a")
	elif fStatus == 2: # Processing;
		os.system("color 0e")
	elif fStatus == 3: #Error;
		os.system("color 0c")
	return
	

#Check if PGAdmin is Running
def fnProcessRunning(fnProcessName):
	s = subprocess.check_output('tasklist', shell=True)
	if fnProcessName.lower() in s.lower():
		fnLogThis("\n\n" + fnProcessName + " is Open\n\tPlease Close PGAdmin before continuing")
		sys.exit()
	else:
		fnLogThis( fnProcessName + " is Closed")
	
				
	
try:	
	fnColor(2)
	fnProcessRunning("PGAdmin3.exe")
	
	#Set Up Temp 1
	fSDEWorkSpaceRelease()
	fDropDB(vSDEDBNameSource)
	fAlterPGPass("postgres")
	fCreateDB(vSDEDBNameSource)
	fCreateSDEConnFile(vSDEDBNameSource)
	fEnableEntGDB(vSDEDBNameSource)
	fSDEDBTune(vSDEDBNameSource)
	fResetPGPass()
	fRegisterAsVersionedFC(vSDEDBNameSource)
	fnColor(1)
	
except Exception, e:
	gvMessage = "FAIL"
	fnColor(3)
	gcErrorMessage = "A Failure Has Occurred\n\nErrorMessage:\n" + e.message + "\n\nESRI Errors:\n" + arcpy.GetMessages() + "\n\nTraceBack Errors:\n" + traceback.format_exc()
	fnLogThis(gcErrorMessage)
	
	
	
finally:
	fnLogThis(vLoggingSegmenter)		
	logging.shutdown()
	 
	if gvMessage == "FAIL":
		raise Exception("Script Failure")
	else:
		sys.stdout.flush()
		#sys.exit(0)
	

