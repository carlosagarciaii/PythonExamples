# POSTGRES stagingData Creation
# Author:	Carlos Garcia II

import os,sys,arcpy,traceback,logging,time,subprocess


global arcLicFilePath
global vPostgresPW
global vSDEPW
global vSourceDatabase
global vTargetDatabase

#Settings
aReplicas = ["lew_unifiedDB_to_stagingData","port_unifiedDB_to_stagingData"] 
vPostgresPW = "AppXNPW"
vSDEPW = "AppXNPW"
arcLicFilePath = "C:/Users/cgarcia/Documents/_Python Scripts/esri_key.ecp"
vSourceDatabase = "unifiedDB"
vTargetDatabase = "stagingData"



#Global Variables
global vWorkingDir
vWorkingDir = str(os.path.dirname(os.path.abspath(__file__)) + "/WorkingDir/" ).replace("\\","/")


global vSDEConnFileSource
vSDEConnFileSource = vWorkingDir + vSourceDatabase + ".sde"
global vSDEConnFileTarget
vSDEConnFileTarget = vWorkingDir + vTargetDatabase + ".sde"
global gvMessage
gvMessage = ""

#Create Working Directory
if not os.path.exists(vWorkingDir):
	print "Output Directory Does Not Exist"
	os.makedirs(vWorkingDir)
else:
	print "Output Directory Exists"


#Logging Setup
logging.basicConfig(filename=vWorkingDir + os.path.basename(__file__) + '_diagnostic.log', format='%(asctime)s %(message)s', level=logging.DEBUG)
vLoggingSegmenter = "Closing Log/n/n________________________________________________________/n________________________________________________________/n/n"


def fnLogThis(vMessage):
	logging.debug(vMessage)
	print vMessage
	

#Altering PGPass.conf to not require a password
def fAlterPGPass(fvPGDB):
	vMessage = "Altering pgpass.conf" 
	print vMessage
	logging.debug(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	print "Updating:\t" + tPGPass
	
	if not os.path.exists(tPGPass):
		print "Does not Exist\t" + tPGPass
		file = open(tPGPass,'w')
		
	else:
		print "Exists\t" + tPGPass
		
		file = open(tPGPass,'w')
	tPGPasstxt = "localhost:5432:" + fvPGDB + ":postgres:" + vPostgresPW
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "Altered pgpass.conf to\t"  + tPGPasstxt + "\n"
	print vMessage
	logging.debug(vMessage)
	return 
	
	
#Creating  database
def fCreateDB(fvDBName):
	vMessage = "Creating Database:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	
	os.system("psql -U postgres -w -c \"CREATE DATABASE " + fvDBName + "  WITH ENCODING='UTF8' OWNER=sde TEMPLATE=template_postgis_20 CONNECTION LIMIT=-1;\"")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created Database:\t" +  fvDBName + "\n"
	print vMessage
	logging.debug(vMessage)	
	return


#dropping database
def fDropDB(fvDBName):
	vMessage = "Dropping Database:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	
	try:
		#fAlterPGPass("stagingData")
		#os.system("psql -h 127.0.0.1 -U postgres -w -c \"UPDATE pg_database SET datallowconn = 'false' WHERE datname = '" + fvDBName + "';\" " + fvDBName)
		#os.system("psql -h 127.0.0.1 -U postgres -w -c \"SELECT pg_terminate_backend(procpid) FROM pg_stat_activity WHERE datname = '" + fvDBName + "';\" " + fvDBName)
		#os.system("psql -h 127.0.0.1 -U postgres -w -c \"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '" + fvDBName + "';\" "  + fvDBName)
		fSDEWorkSpaceRelease()
		fAlterPGPass("postgres")
		os.system("dropdb -U postgres -w " +  fvDBName)
	except Exception, fE:
		vMessage = "Database " +  fvDBName + " Does Not Exist\n"
		print vMessage
		logging.debug(vMessage)	
		
		print(fE.message)
		tb = traceback.format_exc()
		logging.debug("Extended Info:\n\t" + tb)
	
	vMessage = "Database Dropped:\t" +  fvDBName + "\n"
	print vMessage
	logging.debug(vMessage)	
	return	
	
	
#Create SDE Connection File
def fCreateSDEConnFile(fvDBName):
	global vWorkingDir
	
	
	vMessage = "Creating SDE Connection for:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	
	ftSDEConnFile = vWorkingDir + fvDBName + ".sde"
	
	if os.path.exists(ftSDEConnFile):		
		print "Removing " + fvDBName + ".sde"
		os.remove(ftSDEConnFile)
	else:
		print "Creating " + fvDBName + ".sde"

	arcpy.CreateArcSDEConnectionFile_management(vWorkingDir, fvDBName + ".sde", "localhost", "sde:postgresql:localhost", fvDBName, "DATABASE_AUTH", "sde", vSDEPW,"SAVE_USERNAME","sde.DEFAULT","SAVE_VERSION")
			
	global vSDEConnFileTarget	
	sdeConnFile = vWorkingDir + fvDBName + ".sde"
	
	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created SDE Connection for:\t" +  fvDBName + "\n"
	print vMessage
	logging.debug(vMessage)	
	return	
	
	
#Enable Enterprise GeoDatabase
def fEnableEntGDB():	
	print "\n\n"
	global vSDEConnFileTarget
	global arcLicFilePath
	
	vMessage = "Enabling SDE on Database:\t" + vSDEConnFileTarget 
	print vMessage
	logging.debug(vMessage)	
	
	arcpy.EnableEnterpriseGeodatabase_management(vSDEConnFileTarget,arcLicFilePath)	

	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	vMessage = "Enabled SDE on Database:\t" + vSDEConnFileTarget + "\n"
	print vMessage
	logging.debug(vMessage)	
	return	
	
	
def fDisconnectUsers():

	global vSDEConnFileSource
	global vSDEConnFileTarget
	
	print "Disconnecting from:\t" + vSDEConnFileSource
	try:
		arcpy.DisconnectUser(vSDEConnFileSource,"ALL")
	except:
		print vSDEConnFileSource + " does not exist or is not a valid SDE"
		
		
	print "Disconnecting from:\t" + vSDEConnFileTarget
	try:
		arcpy.DisconnectUser(vSDEConnFileTarget,"ALL")
	except:
		print vSDEConnFileSource + " does not exist or is not a valid SDE"
	fSDEWorkSpaceRelease()
	
	return
	
	
#Create Replica	
def fCreateReplica(fvReplicaName):
	global gvMessage
	vMessage = "Creating Replica for:\t" + fvReplicaName + "\n"
	print vMessage
	logging.debug(vMessage)	
	
	global vSDEConnFileSource
	global vSDEConnFileTarget
	global vWorkingDir

	
	print "Getting List of Tables"
	logging.debug("Getting List of Tables")
	
	
	

#Start Importing  GIS	
	print "Setting workspace to:\t" + vSDEConnFileSource
	arcpy.env.workspace = vSDEConnFileSource
	
	SDEMapLayers = []
	
	SDEDataSets = arcpy.ListDatasets()
	SDEFeatures = arcpy.ListFeatureClasses() + arcpy.ListDatasets()

	
	print "\n\nProcessing Feature Classes in Root"
	print "Number of Features: ", len(SDEFeatures)
	vMessage =  "List of Features: ", SDEFeatures
	print vMessage
	logging.debug(vMessage)
	
	
	if len(SDEFeatures) > 0:
		
		for x in range(0,len(SDEFeatures)):
			if "SDE." in SDEFeatures[x]:
				SDEMapLayers.append(SDEFeatures[x]) #[SDEFeatures[x].index("SDE.") + 4:])
			else:
				SDEMapLayers.append(SDEFeatures[x])
		print "Added: ",SDEMapLayers[-1]
	else:
		print "There are no feature Classes in the Root"
		
	
	"""
	fSDEWorkSpaceRelease()
	print "\n\nProcessing Feature Datasets"
	print "Number of Datasets: ", len(SDEDataSets)
	print "List of Datasets: ", SDEDataSets
	
	if len(SDEDataSets) > 0:
		
		for x in range(0,len(SDEDataSets)):
			tFeatureName = SDEDataSets[x]
			
			arcpy.env.workspace = vSDEConnFileSource + "/" + tFeatureName
			print "Feature:\t" + tFeatureName
			SDEFeatures = arcpy.ListFeatureClasses()
			arcpy.env.workspace = ""
			arcpy.ClearWorkspaceCache_management()
			for y in range(0,len(SDEFeatures)):
				if "SDE." in SDEFeatures[y]:
					SDEMapLayers.append(tFeatureName + "/" + SDEFeatures[y][SDEFeatures[y].index("SDE.") + 4:])
					print "Feature:\t" + tFeatureName + "/" + SDEFeatures[y][SDEFeatures[y].index("SDE.") + 4:]
				else:
					SDEMapLayers.append(tFeatureName + "/" + SDEFeatures[y][SDEFeatures[y].index("sde.") + 4:])
					print "Feature:\t" + tFeatureName + "/" + SDEFeatures[y][SDEFeatures[y].index("sde.") + 4:]
				
	else:
		print "There are no Feature Datasets"
	"""
# End Importing  GIS	
	
	
	vLayers = ""
	
	for x in range(0,len(SDEMapLayers)):
		if x == 0:
			vLayers = "'" + vSDEConnFileSource + "/" + str(SDEMapLayers[x]) + "'"
			print  "'" + vSDEConnFileSource + "/" +  str(SDEMapLayers[x]) + "'"
		else:
			vLayers = vLayers + ";'" + vSDEConnFileSource + "/" +  str(SDEMapLayers[x]) + "'"
			print ";'" + vSDEConnFileSource + "/" +  str(SDEMapLayers[x]) + "'"
	vLayersMsg = "\nProcessing Layers:\n\t" + str(vLayers).replace(";",";\n\t") + "\n\n"
	logging.debug(vLayersMsg)
	
	print vLayersMsg

	fSDEWorkSpaceRelease()	

	print "\n\nStarting ESRI Replication\n--------------------------------------\n" + fvReplicaName + "\n"
	vMessage =  "arcpy.CreateReplica_management(" + vLayers + ", \"ONE_WAY_REPLICA\"," + vSDEConnFileTarget + "," + fvReplicaName + ", \"FULL\", \"PARENT_DATA_SENDER\", \"USE_DEFAULTS\", \"DO_NOT_REUSE\", \"GET_RELATED\", \"\", \"DO_NOT_USE_ARCHIVING\") "
	print vMessage
	logging.debug(vMessage)
	
	arcpy.CreateReplica_management(vLayers, "ONE_WAY_REPLICA",vSDEConnFileTarget, fvReplicaName, "FULL", "PARENT_DATA_SENDER", "USE_DEFAULTS", "DO_NOT_REUSE", "GET_RELATED", "", "DO_NOT_USE_ARCHIVING")

	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Replica Created for:\t" + fvReplicaName + "\n"
	print vMessage
	logging.debug(vMessage)
	
	
#Create SQL Backup	
def fPGDump(fvDBName):	
	global vWorkingDir
	
	vMessage = "Creating backup of:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	
	vOSExecute = "pg_dump -U postgres -w -f \"" + vWorkingDir + fvDBName + ".backup\" stagingData"
	print "Executing:\t" + vOSExecute
	os.system(vOSExecute)
	#pg_dump -U sde -w -f c:\mapdata\maine\maine_1317.backup maine
	
	
	vMessage = "Backup Created for:\t" + fvDBName + "\n"
	print vMessage
	logging.debug(vMessage)	
	
	return
	
	
def fSDEDBTune(fvDBName):
	global vPostgresPW
	global vSDEPW
	vMessage = "Setting Spatial Storage for:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)
	#sdedbtune -o alter -k DEFAULTS -P GEOMETRY_STORAGE -v PG_GEOMETRY -s 192.168.11.22 -D live -u sde -p AppXN1 -i sde:postgresql:192.168.11.22
	vOSExecute = "sdedbtune -o alter -k DEFAULTS -P GEOMETRY_STORAGE -v PG_GEOMETRY -s 127.0.0.1 -D " + fvDBName + " -u sde -p " + vSDEPW + " -i sde:postgresql:127.0.0.1 -N"
	print "Executing:\t" + vOSExecute
	os.system(vOSExecute)	
	
	
	vMessage = "Spatial Storage Set for:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)
	return

	
#Releasing Workspace/Locks	
def fSDEWorkSpaceRelease():		
	arcpy.env.workspace = ""
	arcpy.ClearWorkspaceCache_management()
	vMessage = "Workspace Release"
	print vMessage
	logging.debug(vMessage)
	return
	
	
#Color Coding
def fnColor(fStatus):	
	if fStatus == 1: #Standby;
		os.system("color 0a")
	elif fStatus == 2: # Processing;
		os.system("color 0e")
	elif fStatus == 3: #Error;
		os.system("color 0c")
	

#Set FeatureClass as Versioned	
def	fRegisterAsVersionedFC(fvDBName):
	print "\n\n"

	vMessage = "Registering Feature As Versioned\n___________________________________________________"
	print vMessage
	logging.debug(vMessage)
	
	fSDEWorkSpaceRelease()	
	global vWorkingDir
	
	vEnvWorkspace = vWorkingDir  + fvDBName + ".sde"
	print "Setting Workspace to " + vEnvWorkspace
	arcpy.env.workspace = vEnvWorkspace
	
	vLayers = arcpy.ListFeatureClasses() + arcpy.ListDatasets()
	
	logging.debug("Starting Versioning Features")
	print "Starting Versioning Features"
	
	for x in range(0,len(vLayers)):
		
		if arcpy.Describe(vLayers[x]).isVersioned == False:
			print "Registering Version for:\t" + vLayers[x]
			arcpy.RegisterAsVersioned_management(vLayers[x])
			logging.debug("ESRI Message:\n\t" + arcpy.GetMessages())
			print str(arcpy.GetMessages()) + "\n"
		else:
			print "\tIs Versioned\t" + vLayers[x]  
			logging.debug("\tIs Versioned\t" + vLayers[x] )
	
	vMessage = "\n\tLayer Versioning Complete\n\n"
	print vMessage
	logging.debug(vMessage)
	fSDEWorkSpaceRelease()
	return
		
		
#Check if PGAdmin is Running
def fnProcessRunning(fnProcessName):
	s = subprocess.check_output('tasklist', shell=True)
	if fnProcessName.lower() in s.lower():
		fnLogThis("\n\n" + fnProcessName + " is Open\n\tPlease Close PGAdmin before continuing")
		sys.exit()
	else:
		print fnProcessName + " is Closed"
	
			

	
try:
	vMessage = "Starting Process" 
	print vMessage
	logging.debug(vMessage)
	fnColor(2)
	fnProcessRunning("PGAdmin3.exe")
	
	fRegisterAsVersionedFC(vSourceDatabase)

		
	vCompleted = "Replicas Completed:"
	for x in range(0,len(aReplicas)):
		fCreateSDEConnFile(vSourceDatabase) #unifiedDB
		fCreateSDEConnFile(vTargetDatabase) #stagingData
	
		fDisconnectUsers()
		fAlterPGPass("postgres")
		
		
		fDropDB(vTargetDatabase)	
		fCreateDB(vTargetDatabase)		
		fEnableEntGDB()
		fSDEDBTune(vTargetDatabase)
		fCreateReplica(aReplicas[x])
		fRegisterAsVersionedFC(vTargetDatabase)
			
		fAlterPGPass(vTargetDatabase)
		fPGDump(aReplicas[x])
		vCompleted = vCompleted + "\n\t" + aReplicas[x]

	logging.debug(vCompleted)
		
	fnColor(1)	
		
	

except Exception, e:
	gvMessage = "FAIL"
	fnColor(3)
	print(e.message)
	print arcpy.GetMessages()
	tb = traceback.format_exc()
	logging.debug(tb)
	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")

finally:
	logging.debug(vLoggingSegmenter)		
	logging.shutdown()
	"""
	if vMessage == "FAIL":
		raise Exception("Script Failure")
		sys.exit(1)
	"""