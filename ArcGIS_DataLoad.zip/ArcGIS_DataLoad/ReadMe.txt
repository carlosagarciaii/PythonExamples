ArcGIS:		10.2

Description:
	This script is designed to migrate data from a core source and push it to a load balanced set. 
