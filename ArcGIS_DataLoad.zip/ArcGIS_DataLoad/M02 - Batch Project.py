# Author: 	Carlos Garcia II
#	
#	This sscript is designed to batch project from one SDE
#	to another while removing Z & M Values.




import os,sys,arcpy,traceback,logging, datetime,subprocess


global vCoordinateSystem
global vSDEDBNameTarget 
global vPostgresPW
global vSDEPW



# Configuration

vSDEDBNameTarget = "unifiedDB"
vPostgresPW = "AppXNUN"
vSDEPW = "AppXNPW"


vCoordinateSystem = "GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]"

#End Configuration



#Global Variables
global vWorkingDir
vWorkingDir = os.path.dirname(os.path.abspath(__file__)) + "/WorkingDir/"
global gvMessage
gvMessage = "" 


global vTempDBName2
#Get Last SDE Connection File Created
aSDEFilesInDir = []
aFilesInDir = os.listdir(vWorkingDir)
for x in range(0,len(aFilesInDir)):
	if aFilesInDir[x].endswith(".sde") and aFilesInDir[x].startswith("tmp2"):
		aSDEFilesInDir.append(aFilesInDir[x])


vTempDBName2 =  aSDEFilesInDir[len(aSDEFilesInDir) -1].replace(".sde","")


global aDeserializeOriginalGUIDField
aDeserializeOriginalGUIDField = []
global aDeserializeTempGUIDField
aDeserializeTempGUIDField = []
global aDeserializeFeature
aDeserializeFeature = []
global aDeserializeSQLTable
aDeserializeSQLTable = []

#Create Working Directory
if not os.path.exists(vWorkingDir):
	print "Output Directory Does Not Exist"
	os.makedirs(vWorkingDir)
else:
	print "Output Directory Exists"


#Logging Setup
logging.basicConfig(filename=vWorkingDir + os.path.basename(__file__) + '_diagnostic.log', format='%(asctime)s %(message)s', level=logging.DEBUG)
vLoggingSegmenter = "Closing Log\n\n________________________________________________________\n________________________________________________________\n\n"



def fnLogThis(vMessage):
	logging.debug(vMessage)
	print vMessage
	

#Altering PGPass.conf to not require a password
def fAlterPGPass(fvPGDB):
	vMessage = "Altering pgpass.conf" 
	print vMessage
	logging.debug(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	print "Updating:\t" + tPGPass
	
	if not os.path.exists(tPGPass):
		print "Does not Exist\t" + tPGPass
		file = open(tPGPass,'w')
		
	else:
		print "Exists\t" + tPGPass
		
		file = open(tPGPass,'w')
	tPGPasstxt = "localhost:5432:" + fvPGDB + ":postgres:" + vPostgresPW
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "Altered pgpass.conf to\t"  + tPGPasstxt + "\n"
	print vMessage
	logging.debug(vMessage)
	return 

	
#Altering PGPass.conf to not require a password
def fResetPGPass():
	vMessage = "Reseting pgpass.conf" 
	print vMessage
	logging.debug(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	print "Updating:\t" + tPGPass
	
	if not os.path.exists(tPGPass):
		print "Does not Exist\t" + tPGPass
		file = open(tPGPass,'w')
		
	else:
		print "Exists\t" + tPGPass
		
		file = open(tPGPass,'w')
	tPGPasstxt = ""
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "pgpass.conf has been Reset\n"
	print vMessage
	logging.debug(vMessage)
	return 

	
#Releasing Workspace/Locks	
def fSDEWorkSpaceRelease():		
	arcpy.env.workspace = ""
	arcpy.ClearWorkspaceCache_management()
	vMessage = "Workspace Release"
	print vMessage
	logging.debug(vMessage)
	return
	

def fBatchProject():
	print "\n\n"

	vMessage = "Starting Batch Projection\n___________________________________________________"
	print vMessage
	logging.debug(vMessage)
	
	fSDEWorkSpaceRelease()
	
	global vSDEDBNameTarget 
	global vWorkingDir
	global vTempDBName2
	global vCoordinateSystem
	
	sdeConnFile1 = vWorkingDir +  vTempDBName2 + ".sde"
	sdeConnFile2 = vWorkingDir +  vSDEDBNameTarget + ".sde"
	
	print "Disabling M & Z Flags"
	arcpy.env.workspace = sdeConnFile1
	logging.debug("Workspace Set to:\t" + sdeConnFile1)
	

	vLayers = arcpy.ListFeatureClasses() + arcpy.ListDatasets()
	logging.debug("Layers Detected:\n\t" + str(vLayers))
	
	
	logging.debug("Starting Batch Projection")
	print "Starting Batch Projection"
	arcpy.BatchProject_management(vLayers,sdeConnFile2,vCoordinateSystem)
	logging.debug("ESRI Message:\n\t" + arcpy.GetMessages())
	
	
	vMessage = "\n\tBatch Project Module Complete\n\n"
	print vMessage
	logging.debug(vMessage)
	return

	
	
def fnAnalyze(fvSDEConnFile,fvSDEContents):
	#Analyzing Datasets
	vMessage = "Starting Analyze Datasets"
	logging.debug(vMessage)
	print vMessage
	arcpy.AnalyzeDatasets_management(fvSDEConnFile, "SYSTEM", fvSDEContents, "ANALYZE_BASE", "ANALYZE_DELTA", "ANALYZE_ARCHIVE")
	vMessage = "Complete Analyze Datasets\n"
	print arcpy.GetMessages() + "\n"
	logging.debug(arcpy.GetMessages())
	logging.debug(vMessage)	
	print vMessage	

	
def fnCompress(fvSDEConnFile):
	#Compressing SDE
	vMessage = "Starting SDE Compress"
	logging.debug(vMessage)
	print vMessage	
	arcpy.Compress_management(fvSDEConnFile)
	vMessage = "Complete SDE Compress \n"
	print arcpy.GetMessages() + "\n"
	logging.debug(arcpy.GetMessages())
	logging.debug(vMessage)
	print vMessage	

	
def fnIndexRebuild(fvSDEConnFile,fvSDEContents):
	#Rebuilding Indexes
	vMessage = "Starting Rebuild Indexes"
	logging.debug(vMessage)
	print vMessage
	arcpy.RebuildIndexes_management(fvSDEConnFile,"SYSTEM", fvSDEContents, "ALL")
	vMessage = "Complete Rebuild Indexes \n"
	print arcpy.GetMessages() + "\n"
	logging.debug(arcpy.GetMessages())
	logging.debug(vMessage)
	print vMessage
	
	
def fnOptimize():
	
	global vSDEDBNameTarget 
	global vWorkingDir
	
	sdeConnFile = vWorkingDir +  vSDEDBNameTarget + ".sde"
	arcpy.env.workspace = sdeConnFile
	vSDEContents = arcpy.ListDatasets() + arcpy.ListFeatureClasses()
	fnAnalyze(sdeConnFile,vSDEContents)
	fnCompress(sdeConnFile)
	fnAnalyze(sdeConnFile,vSDEContents)
	fnIndexRebuild(sdeConnFile,vSDEContents)
	
	
#Set FeatureClass as Versioned	
def	fRegisterAsVersionedFC():
	print "\n\n"

	vMessage = "Registering Feature As Versioned\n___________________________________________________"
	print vMessage
	logging.debug(vMessage)
	
	fSDEWorkSpaceRelease()	
	global vSDEDBNameTarget 
	global vWorkingDir
	global vCoordinateSystem
	
	sdeConnFile1 = vWorkingDir +  vSDEDBNameTarget + ".sde"
	
	arcpy.env.workspace = sdeConnFile1
	vLayers = arcpy.ListFeatureClasses() + arcpy.ListDatasets()
	
	logging.debug("Starting Versioning Features")
	print "Starting Versioning Features"
	
	for x in range(0,len(vLayers)):
		
		if arcpy.Describe(vLayers[x]).isVersioned == False:
			print "Registering Version for:\t" + vLayers[x]
			arcpy.RegisterAsVersioned_management(vLayers[x])
			logging.debug("ESRI Message:\n\t" + arcpy.GetMessages())
			print str(arcpy.GetMessages()) + "\n"
		else:
			print "\tIs Versioned\t" + vLayers[x]  
			logging.debug("\tIs Versioned\t" + vLayers[x] )
	
	vMessage = "\n\tLayer Versioning Complete\n\n"
	print vMessage
	logging.debug(vMessage)
	fSDEWorkSpaceRelease()
	return


def fnColor(fStatus):	
	print "\n\n"

	if fStatus == 1: #Standby;
		os.system("color 0a")
	elif fStatus == 2: # Processing;
		os.system("color 0e")
	elif fStatus == 3: #Error;
		os.system("color 0c")
	return
	

#Check if PGAdmin is Running
def fnProcessRunning(fnProcessName):
	s = subprocess.check_output('tasklist', shell=True)
	if fnProcessName.lower() in s.lower():
		fnLogThis("\n\n" + fnProcessName + " is Open\n\tPlease Close PGAdmin before continuing")
		sys.exit()
	else:
		print fnProcessName + " is Closed"
	
	
	
try:
	
	fnColor(2)
	fnProcessRunning("PGAdmin3.exe")
	fBatchProject()	
	fResetPGPass()
	fRegisterAsVersionedFC()
	fnOptimize()
	
	
	vMessage = "Batch Projection Complete"
	print vMessage
	logging.debug(vMessage)	
	
	fnColor(1)
	
except Exception, e:
	gvMessage = "FAIL"
	fnColor(3)
	print(e.message)
	print arcpy.GetMessages()
	tb = traceback.format_exc()
	logging.debug(tb)
	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
	
finally:
	if gvMessage == "FAIL":
		raise Exception("Script Failure")

	logging.debug(vLoggingSegmenter)		
	logging.shutdown()
