# Author: 	Carlos Garcia II
#	
#	This sscript is designed to batch project from one SDE
#	to another while removing Z & M Values.




import os,sys,arcpy,traceback,logging, datetime,subprocess


global vCoordinateSystem
global vSDEDBNameSource 
global vSDEDBNameTarget 
global vPostgresPW
global vSDEPW
global varcLicFilePath



# Configuration

vSDEDBNameSource = "countyName"
vSDEDBNameTarget = "unifiedDB"
vPostgresPW = "AppXNUN"
vSDEPW = "AppXNPW"
varcLicFilePath = "C:/Users/cgarcia/Documents/_Python Scripts/esri_key.ecp"


vCoordinateSystem = "GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]"

#End Configuration




#Global Variables
global vWorkingDir
vWorkingDir = str(os.path.dirname(os.path.abspath(__file__)) + "/WorkingDir/").replace("\\","/")
global gvMessage
gvMessage = "" 
global vTempDBName1
vTempDBName1 = "tmp1" + str(datetime.datetime.now()).replace(" ","").replace("-","").replace(":","")[:12]
global vTempDBName2
vTempDBName2 = "tmp2" + str(datetime.datetime.now()).replace(" ","").replace("-","").replace(":","")[:12]



global aDeserializeOriginalGUIDField
aDeserializeOriginalGUIDField = []
global aDeserializeTempGUIDField
aDeserializeTempGUIDField = []
global aDeserializeFeature
aDeserializeFeature = []
global aDeserializeSQLTable
aDeserializeSQLTable = []

#Create Working Directory
if not os.path.exists(vWorkingDir):
	print "Output Directory Does Not Exist"
	os.makedirs(vWorkingDir)
else:
	print "Output Directory Exists"


#Logging Setup
logging.basicConfig(filename=vWorkingDir + os.path.basename(__file__) + '_diagnostic.log', format='%(asctime)s %(message)s', level=logging.DEBUG)
vLoggingSegmenter = "Closing Log\n\n________________________________________________________\n________________________________________________________\n\n"


def fnLogThis(vMessage):
	logging.debug(vMessage)
	print vMessage
	

#Disable Editor Tracking
def fDisableTracking(fvDBName):	
	vMessage = "Disabling Editor Tracking"
	fnLogThis(vMessage)
	
	global vWorkingDir
	sdeConnFile = vWorkingDir +  fvDBName + ".sde"
	
	fSDEWorkSpaceRelease()
	
	arcpy.env.workspace = sdeConnFile
	fnLogThis("Workspace Set to:\t" + sdeConnFile)
	
	
	aFeatureDataSets = []
	aFeatureClasses = []
	
	aFeatureDataSets = arcpy.ListDatasets()
	aFeatureClasses = arcpy.ListFeatureClasses()
	
	if len(aFeatureClasses) > 0:
		for x in range(0,len(aFeatureClasses)):
			vMessage = "Disabling Edit Tracking for " + aFeatureClasses[x]
			fnLogThis(vMessage)
			arcpy.DisableEditorTracking_management(aFeatureClasses[x]) 
			
			vMessage = arcpy.GetMessages()
			fnLogThis(vMessage)

	if len(aFeatureDataSets) > 0:
		for x in range(0,len(aFeatureDataSets)):

			
			
			fnLogThis( "Finding Layers in:\t" + sdeConnFile + "/" + aFeatureDataSets[x])
			arcpy.env.workspace = sdeConnFile + "/" + aFeatureDataSets[x]
			
			
			aFeatureClasses = arcpy.ListFeatureClasses()
			for y in range(0,len(aFeatureClasses)):
			
				tSourceFeature = 	sdeConnFile + "/" + aFeatureClasses[y]		#.replace(".sde.","").replace(vTempDBName1,"")
				vMessage = "Disabling Edit Tracking for " + aFeatureClasses[x]
				fnLogThis(vMessage)
				arcpy.DisableEditorTracking_management(tSourceFeature)
				
				vMessage = arcpy.GetMessages()
				fnLogThis(vMessage)
				
				
				
			fSDEWorkSpaceRelease()
			
			
#Altering PGPass.conf to not require a password
def fAlterPGPass(fvPGDB):
	vMessage = "Altering pgpass.conf" 
	fnLogThis(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	fnLogThis( "Updating:\t" + tPGPass)
	
	if not os.path.exists(tPGPass):
		fnLogThis("Does not Exist\t" + tPGPass)
		file = open(tPGPass,'w')
		
	else:
		fnLogThis( "Exists\t" + tPGPass)
		
		file = open(tPGPass,'w')
	tPGPasstxt = "localhost:5432:" + fvPGDB + ":postgres:" + vPostgresPW
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "Altered pgpass.conf to\t"  + tPGPasstxt + "\n"
	fnLogThis(vMessage)
	return 


#Altering PGPass.conf to not require a password
def fResetPGPass():
	vMessage = "Reseting pgpass.conf" 
	fnLogThis(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	fnLogThis("Updating:\t" + tPGPass)
	
	if not os.path.exists(tPGPass):
		fnLogThis("Does not Exist\t" + tPGPass)
		file = open(tPGPass,'w')
		
	else:
		fnLogThis("Exists\t" + tPGPass)
		
		file = open(tPGPass,'w')
	tPGPasstxt = ""
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "pgpass.conf has been Reset\n"
	fnLogThis(vMessage)
	return 
	
	
#Creating  database
def fCreateDB(fvDBName):
	vMessage = "Creating Database:\t" +  fvDBName
	fnLogThis(vMessage)	
	
	os.system("psql -U postgres -w -c \"CREATE DATABASE " + fvDBName + "  WITH ENCODING='UTF8' OWNER=sde TEMPLATE=template_postgis_20 CONNECTION LIMIT=-1;\"")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created Database:\t" +  fvDBName + "\n"
	fnLogThis(vMessage)	
	return


#dropping database
def fDropDB(fvDBName):
	vMessage = "Dropping Database:\t" +  fvDBName
	fnLogThis(vMessage)	
	
	try:
		fSDEWorkSpaceRelease()
		fAlterPGPass("postgres")
		os.system("dropdb -U postgres -w " +  fvDBName)
	except Exception, fE:
		vMessage = "Database " +  fvDBName + " Does Not Exist\n"
		fnLogThis(vMessage)	
		
		fnLogThis(fE.message)
		tb = traceback.format_exc()
		fnLogThis("Extended Info:\n\t" + tb)
	
	vMessage = "Database Dropped:\t" +  fvDBName + "\n"
	fnLogThis(vMessage)	
	return	
	
	
#Create SDE Connection File
def fCreateSDEConnFile(fvDBName):
	vMessage = "Creating SDE Connection for:\t" +  fvDBName
	fnLogThis(vMessage)	
	
	ftSDEConnFile = vWorkingDir + fvDBName + ".sde"
	
	if os.path.exists(ftSDEConnFile):		
		fnLogThis( "Removing " + fvDBName + ".sde")
		os.remove(ftSDEConnFile)
	else:
		fnLogThis("Creating " + fvDBName + ".sde")

	arcpy.CreateArcSDEConnectionFile_management(vWorkingDir, fvDBName + ".sde", "localhost", "sde:postgresql:localhost", fvDBName, "DATABASE_AUTH", "sde", vSDEPW,"SAVE_USERNAME","sde.DEFAULT","SAVE_VERSION")
			
	global vSDEDBNameTarget	
	sdeConnFile = vWorkingDir + fvDBName + ".sde"
	
	fnLogThis("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created SDE Connection for:\t" +  fvDBName + "\n"
	fnLogThis(vMessage)	
	return	
	
	
#Enable Enterprise GeoDatabase
def fEnableEntGDB(fvDBName):	
	global varcLicFilePath
	global vWorkingDir
	vSDEConnFile = vWorkingDir + fvDBName + ".sde"
	vMessage = "Enabling SDE on Database:\t" + fvDBName + "\n\tConnFile:\t" + vSDEConnFile + "\n\tLicFile:\t" + varcLicFilePath
	
	fnLogThis(vMessage)	
	
	arcpy.EnableEnterpriseGeodatabase_management(vSDEConnFile,varcLicFilePath)	

	fnLogThis("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	vMessage = "Enabled SDE on Database:\t" + vSDEDBNameTarget + "\n"
	fnLogThis(vMessage)	
	return	
	
	
def fDisconnectUsers():

	global vSDEDBNameSource
	global vSDEDBNameTarget
	global vWorkingDir
	SDEConnFile1 = vWorkingDir + vSDEDBNameSource	
	SDEConnFile2 = vWorkingDir + vSDEDBNameTarget
	
	fnLogThis("Disconnecting from:\t" + SDEConnFile1)
	try:
		arcpy.DisconnectUser(SDEConnFile1,"ALL")
	except:
		fnLogThis(SDEConnFile1 + " does not exist or is not a valid SDE")
		
		
	fnLogThis("Disconnecting from:\t" + SDEConnFile2)
	try:
		arcpy.DisconnectUser(SDEConnFile2,"ALL")
	except:
		fnLogThis( SDEConnFile1 + " does not exist or is not a valid SDE")
	fSDEWorkSpaceRelease()
	
	return
	
	
def fSDEDBTune(fvDBName):
	global vPostgresPW
	global vSDEPW
	vMessage = "Setting Spatial Storage for:\t" +  fvDBName
	fnLogThis(vMessage)
	#sdedbtune -o alter -k DEFAULTS -P GEOMETRY_STORAGE -v PG_GEOMETRY -s 192.168.11.22 -D live -u sde -p AppXN1 -i sde:postgresql:192.168.11.22
	vOSExecute = "sdedbtune -o alter -k DEFAULTS -P GEOMETRY_STORAGE -v PG_GEOMETRY -s 127.0.0.1 -D " + fvDBName + " -u sde -p " + vSDEPW + " -i sde:postgresql:127.0.0.1 -N"
	fnLogThis( "Executing:\t" + vOSExecute)
	os.system(vOSExecute)	
	
	
	vMessage = "Spatial Storage Set for:\t" +  fvDBName + "\n\n"
	fnLogThis(vMessage)
	return

	
#Releasing Workspace/Locks	
def fSDEWorkSpaceRelease():		
	arcpy.env.workspace = ""
	arcpy.ClearWorkspaceCache_management()
	vMessage = "Workspace Release"
	fnLogThis(vMessage)
	return

	
def fConvert():
	print "\n\n"

	vMessage = "Starting Conversion Process\n___________________________________________________"
	
	fnLogThis(vMessage)
	
	global vTempDBName1 
	global vWorkingDir
	global vTempDBName2
	
	sdeConnFile1 = vWorkingDir +  vTempDBName1 + ".sde"
	sdeConnFile2 = vWorkingDir +  vTempDBName2 + ".sde"
	
	print "Disabling M & Z Flags"
	arcpy.env.workspace = sdeConnFile1
	fnLogThis("Workspace Set to:\t" + sdeConnFile1)
	arcpy.env.outputZFlag = "Disabled"
	arcpy.env.outputMFlag = "Disabled"
	
	
	aFeatureDataSets = []
	aFeatureClasses = []
	
	aFeatureDataSets = arcpy.ListDatasets()
	aFeatureClasses = arcpy.ListFeatureClasses()
	fnLogThis("\n\t" + str(aFeatureDataSets) + "\n\t" + str(aFeatureClasses))
	print len(aFeatureClasses)
	
#Pulling Feature Classes and formatting for 
	if len(aFeatureClasses) > 0:
		for x in range(0,len(aFeatureClasses)):
			vSpatialReference = arcpy.Describe(aFeatureClasses[x]).SpatialReference
			print "Processing:\t" + aFeatureClasses[x] + "\n\tSP_Ref = \t"	+ str(vSpatialReference)	
			fnLogThis("Processing:\t" + aFeatureClasses[x] + "\n\tSP_Ref = \t"	+ str(vSpatialReference))
			
			tSourceFeature = 	sdeConnFile1 + "/" + aFeatureClasses[x].lower().replace(".sde.","").replace(vTempDBName1,"")
			tTargetPath = 		sdeConnFile2 # + "/" + aFeatureClasses[x].replace(vTempDBName1,vTempDBName2)
			tTargetFeature = 	aFeatureClasses[x].replace(".sde.","").replace(vTempDBName1,"")
			vMessage = "\nConverting:\t" + sdeConnFile1 + "/" + aFeatureClasses[x] + "\n\n\tSource:\t\t" + tSourceFeature + "\n\tTarget Path:\t" + tTargetPath + "\n\tTarget Name:\t" + tTargetFeature + "\n\n"
			
			fnLogThis(vMessage)
			
			
			arcpy.FeatureClassToFeatureClass_conversion(tSourceFeature,tTargetPath,tTargetFeature)
	
#Pulling Feature Datasets	
	if len(aFeatureDataSets) > 0:
		for x in range(0,len(aFeatureDataSets)):
			vSpatialReference = arcpy.Describe(aFeatureDataSets[x]).SpatialReference
			print "Creating FeatureDataSet:\t" + str(aFeatureDataSets[x]) + "\n\tSP_Ref = \t" + str(vSpatialReference)	
			fnLogThis("Creating FeatureDataSet:\t" + str(aFeatureDataSets[x]) + "\n\tSP_Ref = \t" + str(vSpatialReference))
			
			
			arcpy.CreateFeatureDataset_management(sdeConnFile2,aFeatureDataSets[x],vSpatialReference)
			vTargetFeatureDataSet = vTempDBName1 + ".sde/" + aFeatureDataSets[x]
			
			print "Finding Layers in:\t" + sdeConnFile1 + "/" + aFeatureDataSets[x]
			arcpy.env.workspace = sdeConnFile1 + "/" + aFeatureDataSets[x]
			arcpy.env.outputZFlag = "Disabled"
			arcpy.env.outputMFlag = "Disabled"
			
			
			aFeatureClasses = arcpy.ListFeatureClasses()
			for y in range(0,len(aFeatureClasses)):
			
				tSourceFeature = 	sdeConnFile1 + "/" + aFeatureClasses[y]		#.replace(".sde.","").replace(vTempDBName1,"")
				tTargetPath = 		sdeConnFile2 + "/" + aFeatureDataSets[x].replace(vTempDBName1,vTempDBName2)
				tTargetFeature = 	aFeatureClasses[y].replace(".sde.","").replace(vTempDBName1,"")
				vMessage = "\nConverting:\t" + sdeConnFile1 + "/" + aFeatureDataSets[x] + "/" + aFeatureClasses[y] + "\n\n\tSource:\t\t" + tSourceFeature + "\n\tTarget Path:\t" + tTargetPath + "\n\tTarget Name:\t" + tTargetFeature + "\n\n"
				
				fnLogThis(vMessage)
				
				
				arcpy.FeatureClassToFeatureClass_conversion(tSourceFeature,tTargetPath,tTargetFeature)
				
				vTargetFeatureDataSet = sdeConnFile2 + "/" + aFeatureClasses[y]
				
			fSDEWorkSpaceRelease()
			
			
	vMessage = "\n\tCompleted Conversion Module\n\n"
	
	fnLogThis(vMessage)
	return
	#arcpy.FeatureClassToFeatureClass_conversion (in_path, out_path, out_name)

	
def fBatchProject():
	print "\n\n"

	vMessage = "Starting Batch Projection\n___________________________________________________"
	
	fnLogThis(vMessage)
	
	fSDEWorkSpaceRelease()
	
	global vSDEDBNameTarget 
	global vWorkingDir
	global vTempDBName2
	global vCoordinateSystem
	
	sdeConnFile1 = vWorkingDir +  vTempDBName2 + ".sde"
	sdeConnFile2 = vWorkingDir +  vSDEDBNameTarget + ".sde"
	
	print "Disabling M & Z Flags"
	arcpy.env.workspace = sdeConnFile1
	fnLogThis("Workspace Set to:\t" + sdeConnFile1)
	#arcpy.env.outputZFlag = "Disabled"
	#arcpy.env.outputMFlag = "Disabled"
	

	vLayers = arcpy.ListFeatureClasses() + arcpy.ListDatasets()
	fnLogThis("Layers Detected:\n\t" + str(vLayers))
	
	
	fnLogThis("Starting Batch Projection")
	print "Starting Batch Projection"
	arcpy.BatchProject_management(vLayers,sdeConnFile2,vCoordinateSystem)
	fnLogThis("ESRI Message:\n\t" + arcpy.GetMessages())
	
	
	vMessage = "\n\tBatch Project Module Complete\n\n"
	
	fnLogThis(vMessage)
	return

	
#Set FeatureClass as Versioned	
def	fRegisterAsVersionedFC():
	print "\n\n"

	vMessage = "Registering Feature As Versioned\n___________________________________________________"
	
	fnLogThis(vMessage)
	
	fSDEWorkSpaceRelease()	
	global vSDEDBNameTarget 
	global vWorkingDir
	global vTempDBName1
	global vCoordinateSystem
	
	sdeConnFile1 = vWorkingDir +  vSDEDBNameTarget + ".sde"
	
	arcpy.env.workspace = sdeConnFile1
	vLayers = arcpy.ListFeatureClasses() + arcpy.ListDatasets()
	
	fnLogThis("Starting Versioning Features")
	print "Starting Versioning Features"
	
	for x in range(0,len(vLayers)):
		
		if arcpy.Describe(vLayers[x]).isVersioned == False:
			print "Registering Version for:\t" + vLayers[x]
			arcpy.RegisterAsVersioned_management(vLayers[x])
			fnLogThis("ESRI Message:\n\t" + arcpy.GetMessages())
			print str(arcpy.GetMessages()) + "\n"
		else:
			print "\tIs Versioned\t" + vLayers[x]  
			fnLogThis("\tIs Versioned\t" + vLayers[x] )
	
	vMessage = "\n\tLayer Versioning Complete\n\n"
	
	fnLogThis(vMessage)
	fSDEWorkSpaceRelease()
	return

	
def fnColor(fStatus):	
	print "\n\n"

	if fStatus == 1: #Standby;
		os.system("color 0a")
	elif fStatus == 2: # Processing;
		os.system("color 0e")
	elif fStatus == 3: #Error;
		os.system("color 0c")
	return
	
	
def fDeserializeGlobalID(fvDBName):
	print "\n\n"
	vMessage = "Beginning Deserialization\n___________________________________________________"
	
	fnLogThis(vMessage)
	
	global vWorkingDir
	vSDEConnFile = vWorkingDir + fvDBName + ".sde"
	global aDeserializeOriginalGUIDField
	global aDeserializeTempGUIDField
	global aDeserializeFeature
	global aDeserializeSQLTable
	
	fAlterPGPass(fvDBName) 

	arcpy.env.workspace = vSDEConnFile
	fnLogThis("Workspace Set to:\t" + vSDEConnFile)
	
	
	aFeatureClasses = []
	aFeatureClasses = arcpy.ListFeatureClasses() 
	aFeatureDataSets = []
	aFeatureDataSets = arcpy.ListDatasets()
	

	if len(aFeatureClasses) > 0:
		print "Processing Feature Classes from Root"
		for x in range(0,len(aFeatureClasses)):
			tFeature = vSDEConnFile + "/" + aFeatureClasses[x] #.lower().replace(".sde.","").replace(vSDEDBNameSource,"")
			tFeatureDBTable = aFeatureClasses[x] #.lower().replace(".sde.","").replace(fvDBName,"")
			
			for f in arcpy.ListFields(tFeature):
				
				#Delete Date Fields
				if (f.type == 'Date'):
					vMessage = "Removing Date Field:\t" + str(f.name)
					
					fnLogThis(vMessage)
					arcpy.DeleteField_management(tFeature,str(f.name))
					
			
				#arcpy.AddMessage('{},{},{}'.format(f.name, f.type,f.length))
				if (f.type == 'SmallInteger' and f.length == 38) or (f.type == 'Guid'):
				
					vGUIDField = str(f.name)
					aDeserializeOriginalGUIDField.append(vGUIDField)
					aDeserializeFeature.append(tFeatureDBTable)
					aDeserializeSQLTable.append(aFeatureClasses[x].lower().replace(".sde.","").replace(fvDBName,""))
					vtGUIDField = str(f.name) + "Temp"
					aDeserializeTempGUIDField.append(vtGUIDField)
					vMessage = "Detected:\n\tFeature:\t" + 	tFeatureDBTable + "\n\t\tOld Field:\t" + vGUIDField + "\n\t\tNew Field:\t" + vtGUIDField + "\n"
					
					fnLogThis(vMessage)
					
					try:
						#Delete Field if it already exists
						arcpy.DeleteField_management(tFeature,vtGUIDField)
						vMessage = vtGUIDField + " field Exists in " + tFeature + ". Removing"
						
						fnLogThis(vMessage)

					except:
						print "\t\t" + vtGUIDField  + " does not exist"
						
					
					
					vMessage = "\nAdding:\ttGUID\n\tTo:\t" + tFeature + "\n"
					
					fnLogThis(vMessage)		
					
					
					arcpy.AddField_management(tFeature,vtGUIDField,"TEXT") #, "", "", "50", "", "NULLABLE", "NON_REQUIRED", "")

											
					
					vMessage = "Calculating From: " + vGUIDField + " To: " + vtGUIDField
					
					fnLogThis(vMessage)
#					arcpy.CalculateField_management(tFeature, vtGUIDField, "!" + vGUIDField + "!","PYTHON")
						
					vPSQLQuery = "update sde." + aDeserializeSQLTable[-1] + " set " +  aDeserializeTempGUIDField[-1] + " = " +  aDeserializeOriginalGUIDField[-1]



					print vPSQLQuery
					fnLogThis(vPSQLQuery)
					vPGExecute = arcpy.ArcSDESQLExecute(vSDEConnFile)
					
					vPGExecute.execute(vPSQLQuery)
			
			
					"""
					vPSQLQuery = "psql -U postgres -w -c \"update sde." + aDeserializeSQLTable[-1] + " set " + aDeserializeTempGUIDField[-1]  + " = " + aDeserializeOriginalGUIDField[-1] + "\" " + fvDBName
					vMessage = "Processing:\t" + aDeserializeOriginalGUIDField[x] + " on " + aDeserializeFeature[x]
					
					fnLogThis(vMessage)
					print vPSQLQuery
					fnLogThis(vPSQLQuery)
					os.system(vPSQLQuery)
					"""
			
			
			
	if len(aFeatureDataSets) > 0:
		print "Processing DataSets"
		for x in range(0,len(aFeatureDataSets)):
			vSpatialReference = arcpy.Describe(aFeatureDataSets[x]).SpatialReference
			print "Creating FeatureDataSet:\t" + str(aFeatureDataSets[x]) + "\n\tSP_Ref = \t" + str(vSpatialReference)	
			fnLogThis("Creating FeatureDataSet:\t" + str(aFeatureDataSets[x]) + "\n\tSP_Ref = \t" + str(vSpatialReference))

			
			
			print "Finding Layers in:\t" + vSDEConnFile + "/" + str(aFeatureDataSets[x])
			arcpy.env.workspace = vSDEConnFile + "/" + aFeatureDataSets[x]
			
			
			aFeatureClasses = arcpy.ListFeatureClasses()
			print "Feature Classes:\t" + str(aFeatureClasses) + "\n\n"
			
			for y in range(0,len(aFeatureClasses)):
				tFeature = vSDEConnFile + "/" + aFeatureDataSets[x] + "/" + aFeatureClasses[y] #.replace(".sde.","").replace(vSDEDBNameSource,"")
				tFeatureDBTable = aFeatureClasses[y] #.replace(".sde.","").replace(fvDBName,"")
				
				
			
				for f in arcpy.ListFields(tFeature):
					
					#Delete Date Fields
					if (f.type == 'Date'):					
						vMessage = "Removing Date Field:\t" + str(f.name)
						
						fnLogThis(vMessage)
						arcpy.DeleteField_management(tFeature,str(f.name))
						
					
					#arcpy.AddMessage('{},{},{}'.format(f.name, f.type,f.length))
					if (f.type == 'SmallInteger' and f.length == 38) or (f.type == 'Guid'):
						vGUIDField = str(f.name)
						aDeserializeOriginalGUIDField.append(vGUIDField)
						aDeserializeFeature.append(tFeature)
						aDeserializeSQLTable.append(aFeatureClasses[y].replace(".sde.","").replace(fvDBName,""))
						vtGUIDField = str(f.name) + "Temp"
						aDeserializeTempGUIDField.append(vtGUIDField)
						vMessage = "Detected:\n\tFeature:\t" + 	tFeatureDBTable + "\n\t\tOld Field:\t" + vGUIDField + "\n\t\tNew Field:\t" + vtGUIDField + "\n"
						
						fnLogThis(vMessage)
							
							
							
						try:
							#Delete Field if it Exists
							arcpy.DeleteField_management(tFeature,vtGUIDField)
							vMessage = vtGUIDField + " field Exists in " + tFeature + ". Removing"
							
							fnLogThis(vMessage)
						except:
							print "\t\t" + vtGUIDField  + " does not exist"
							
							
						vMessage = "\nAdding:\ttGUID\n\tTo:\t" + tFeature + "\n"
						
						fnLogThis(vMessage)		
						
						
						arcpy.AddField_management(tFeature,vtGUIDField,"TEXT") #, "", "", "50", "", "NULLABLE", "NON_REQUIRED", "")
						
						
						
						vMessage = "Calculating From: " + vGUIDField + " To: " + vtGUIDField
						
						fnLogThis(vMessage)
#						arcpy.CalculateField_management(tFeature, vtGUIDField, "!" + vGUIDField + "!","PYTHON")
#						arcpy.CalculateField_management(tFeature, vtGUIDField, "!" + vGUIDField + "!")
						
										
						vPSQLQuery = "update sde." + aDeserializeSQLTable[-1] + " set " +  aDeserializeTempGUIDField[-1] + " = " +  aDeserializeOriginalGUIDField[-1]
						



						print vPSQLQuery
						fnLogThis(vPSQLQuery)
						vPGExecute = arcpy.ArcSDESQLExecute(vSDEConnFile)
						
						vPGExecute.execute(vPSQLQuery)
		
						

						"""
						vPSQLQuery = "psql -U postgres -w -c \"update sde." + aDeserializeSQLTable[-1] + " set " + aDeserializeTempGUIDField[-1]  + " = " + aDeserializeOriginalGUIDField[-1] + "\" " + fvDBName
						vMessage = "Processing:\t" + aDeserializeOriginalGUIDField[x] + " on " + aDeserializeFeature[x]
						
						fnLogThis(vMessage)
						print vPSQLQuery
						fnLogThis(vPSQLQuery)
						os.system(vPSQLQuery)
						"""
						
						
						
	vMessage = "GlobalID's Processed"
	for x in range(0,len(aDeserializeFeature)):
		vMessage = vMessage + "\n\tFeature:\t" + aDeserializeFeature[x] + "\n\t\tOld GlobalID:\t" +  aDeserializeOriginalGUIDField[x] + "\n\t\tNew GlobalID:\t" + aDeserializeTempGUIDField[x]
		aDeserializeTempGUIDField
	
	
	fnLogThis(vMessage)
	
	return
	
	
def fSerializeGlobalID(fvDBName,fnDBNamePrev):
	print "\n\n"
	global vWorkingDir
	vSDEConnFile = vWorkingDir + fvDBName + ".sde"
	global aDeserializeOriginalGUIDField
	global aDeserializeTempGUIDField
	global aDeserializeFeature
	global aDeserializeSQLTable
	
	vMessage = "Beginning GlobalID Serialization\n___________________________________________________"
	
	fnLogThis(vMessage)
	
	fAlterPGPass(fvDBName) 
	
	for x in range(0,len(aDeserializeOriginalGUIDField)):		
		
#		vPSQLQuery = "psql -U postgres -w -c \"update sde." + aDeserializeSQLTable[x] + " set " + aDeserializeOriginalGUIDField[x] + " = " + aDeserializeTempGUIDField[x] + "\" " + fvDBName
		
		vPSQLQuery = "update sde." + aDeserializeSQLTable[x] + " set " + aDeserializeOriginalGUIDField[x] + " = " + aDeserializeTempGUIDField[x] 
		

		vMessage = "Processing:\t" + aDeserializeOriginalGUIDField[x] + " on " + aDeserializeFeature[x].replace(fnDBNamePrev,fvDBName)
		
		fnLogThis(vMessage)



		print vPSQLQuery
		fnLogThis(vPSQLQuery)
		vPGExecute = arcpy.ArcSDESQLExecute(vSDEConnFile)
		
		vPGExecute.execute(vPSQLQuery)
		
#		os.system(vPSQLQuery)
		
		vMessage = "Deleting Field:\t" + aDeserializeTempGUIDField[x] + "\n\tFrom:\t" + aDeserializeFeature[x].replace(fnDBNamePrev,fvDBName)
		
		fnLogThis(vMessage)
#DEBUG		arcpy.DeleteField_management(aDeserializeFeature[x].replace(fnDBNamePrev,fvDBName),aDeserializeTempGUIDField[x])
	
	return

	
def fExportXML(fvDBName,fvDBName2):
	print "\n\n"
	vMessage = "Beginning Export Features to XML\n___________________________________________________"
	
	fnLogThis(vMessage)
	
	global vWorkingDir
	vSDEConnFile = vWorkingDir + fvDBName + ".sde"	
	vSDEConnFile2 = vWorkingDir + fvDBName2 + ".sde"
	global aDeserializeOriginalGUIDField
	global aDeserializeFeature
	
	arcpy.env.workspace = vSDEConnFile

	
	vFeatures = arcpy.ListDatasets() + arcpy.ListFeatureClasses()
	print "Features to Export" + str(vFeatures)
	
	for x in range(0,len(vFeatures)):
	
		vExportFile = vWorkingDir  + fvDBName + " - " + vFeatures[x] +  "_Export.xml"
		if os.path.exists(vExportFile):
			os.remove(vExportFile)
		
		vMessage = "Creating Export File:\n\t" + vExportFile
		
		fnLogThis(vMessage)
		arcpy.ExportXMLWorkspaceDocument_management(vFeatures[x],vExportFile,"DATA")
		
		#Importing XML
		vMessage = "Importing XML File:\t" + vExportFile + "\n\tTo:\t" + vSDEConnFile2
		
		fnLogThis(vMessage)
		arcpy.ImportXMLWorkspaceDocument_management(vSDEConnFile2,vExportFile,"DATA")
	return
	

#Check if PGAdmin is Running
def fnProcessRunning(fnProcessName):
	s = subprocess.check_output('tasklist', shell=True)
	if fnProcessName.lower() in s.lower():
		fnLogThis("\n\n" + fnProcessName + " is Open\n\tPlease Close PGAdmin before continuing")
		sys.exit()
	else:
		print fnProcessName + " is Closed"
	
	
	
try:
		
		
	fnColor(2)
	fnProcessRunning("PGAdmin3.exe")
	
	fCreateSDEConnFile(vSDEDBNameSource)

	fCreateSDEConnFile(vTempDBName1)
	fCreateSDEConnFile(vTempDBName2)
	
	fDisableTracking(vSDEDBNameSource)
	
	
	#Set Up Temp 1
	fSDEWorkSpaceRelease()
	fDropDB(vTempDBName1)
	fAlterPGPass("postgres")
	fCreateDB(vTempDBName1)
	fCreateSDEConnFile(vTempDBName1)
	fEnableEntGDB(vTempDBName1)
	fSDEDBTune(vTempDBName1)
	
	#Set Up Temp 2
	fSDEWorkSpaceRelease()
	fDropDB(vTempDBName2)
	fAlterPGPass("postgres")
	fCreateDB(vTempDBName2)
	fCreateSDEConnFile(vTempDBName2)
	fEnableEntGDB(vTempDBName2)
	fSDEDBTune(vTempDBName2)
	
	#Set Up unifiedDB
	fSDEWorkSpaceRelease()
	fDropDB(vSDEDBNameTarget)
	fAlterPGPass("postgres")
	fCreateDB(vSDEDBNameTarget)
	fCreateSDEConnFile(vSDEDBNameTarget)
	fEnableEntGDB(vSDEDBNameTarget)
	fSDEDBTune(vSDEDBNameTarget)
	
	fExportXML(vSDEDBNameSource,vTempDBName1)
	
	
	
	fDeserializeGlobalID(vTempDBName1)

	fConvert()
	fSerializeGlobalID(vTempDBName2,vTempDBName1)
	
	
	#Yup
	"""
			fBatchProject()	
			fResetPGPass()
			fRegisterAsVersionedFC()
	"""
	
	vMessage = "Temp Database Setup Complete"
	
	fnLogThis(vMessage)
	
	
	fnColor(1)
	
except Exception, e:
	gvMessage = "FAIL"
	fnColor(3)
	fnLogThis("A Failure Has Occurred")
	print(e.message)
	print arcpy.GetMessages()
	tb = traceback.format_exc()
	fnLogThis(tb)
	fnLogThis("\n\n" + arcpy.GetMessages() + "\n\n")
	
finally:
	fnLogThis(vLoggingSegmenter)		
	logging.shutdown()
	"""
	if gvMessage == "FAIL":
		raise Exception("Script Failure")
	else:
		sys.stdout.flush()
		#sys.exit(0)
	"""
	

