# Author: 	Carlos Garcia II
#	
#	This script is designed to batch project from one SDE
#	to another while removing Z & M Values.
#



import os,sys,arcpy,traceback,logging, datetime,subprocess


global vCoordinateSystem
global vSDEDBNameSource 
global vSDEDBNameTarget 
global vPostgresPW
global vSDEPW
global varcLicFilePath
global vReplicaName
global vPGDumpFile

# Configuration

vSDEDBNameSource = "stagingData"
vSDEDBNameTarget = "live"
vPostgresPW = "AppXNPW"
vSDEPW = "AppXNPW"
vReplicaName = "stagingData_to_live"
varcLicFilePath = "C:/Users/cgarcia/Documents/_Python Scripts/esri_key.ecp"


vCoordinateSystem = "GEOGCS['GCS_WGS_1984',DATUM['D_WGS_1984',SPHEROID['WGS_1984',6378137.0,298.257223563]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]]"

#End Configuration




#Global Variables
global vWorkingDir
vWorkingDir = os.path.dirname(os.path.abspath(__file__)) + "/WorkingDir/"
global gvMessage
gvMessage = "" 
global vTempDBName
vTempDBName = "tmp" + str(datetime.datetime.now()).replace(" ","").replace("-","").replace(":","")[:12]
global vRollbackDB
vRollbackDB = "rollback"


#Create Working Directory
if not os.path.exists(vWorkingDir):
	print "Output Directory Does Not Exist"
	os.makedirs(vWorkingDir)
else:
	print "Output Directory Exists"


#Logging Setup
logging.basicConfig(filename=vWorkingDir + os.path.basename(__file__) + '_diagnostic.log', format='%(asctime)s %(message)s', level=logging.DEBUG)
vLoggingSegmenter = "Closing Log\n\n________________________________________________________\n________________________________________________________\n\n"


#Altering PGPass.conf to not require a password
def fAlterPGPass(fvPGDB):
	vMessage = "Altering pgpass.conf" 
	print vMessage
	logging.debug(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	print "Updating:\t" + tPGPass
	
	if not os.path.exists(tPGPass):
		print "Does not Exist\t" + tPGPass
		file = open(tPGPass,'w')
		
	else:
		print "Exists\t" + tPGPass
		
		file = open(tPGPass,'w')
	tPGPasstxt = "127.0.0.1:5432:" + fvPGDB + ":postgres:" + vPostgresPW
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "Altered pgpass.conf to\t"  + tPGPasstxt + "\n"
	print vMessage
	logging.debug(vMessage)
	return 

	
#Altering PGPass.conf to not require a password
def fResetPGPass():
	vMessage = "Reseting pgpass.conf" 
	print vMessage
	logging.debug(vMessage)	
	
	tPGPass = os.environ['AppData'] + "/postgresql/pgpass.conf"
	print "Updating:\t" + tPGPass
	
	if not os.path.exists(tPGPass):
		print "Does not Exist\t" + tPGPass
		file = open(tPGPass,'w')
		
	else:
		print "Exists\t" + tPGPass
		
		file = open(tPGPass,'w')
	tPGPasstxt = ""
	file = open(tPGPass,'w')
	file.write(tPGPasstxt)	
	file.close()
	
	vMessage = "pgpass.conf has been Reset\n"
	print vMessage
	logging.debug(vMessage)
	return 
	
	
#Creating  database
def fCreateDB(fvDBName):

	vMessage = "Creating Database:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	cmdEXE = "psql -h 127.0.0.1 -U postgres -w -c \"CREATE DATABASE " + fvDBName + "  WITH ENCODING='UTF8' OWNER=sde TEMPLATE=template_postgis_20 CONNECTION LIMIT=-1;\""
	
	vMessage = "Command Line:\n\t" + cmdEXE
	print vMessage
	logging.debug(vMessage)
	
	os.system(cmdEXE)
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created Database:\t" +  fvDBName + "\n"
	print vMessage
	logging.debug(vMessage)	
	return
	

#dropping database
def fDropDB(fvDBName):
	vMessage = "Dropping Database:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	
	try:
		fSDEWorkSpaceRelease()
		fAlterPGPass("postgres")
		os.system("dropdb -U postgres -w " +  fvDBName)
	except Exception, fE:
		vMessage = "Database " +  fvDBName + " Does Not Exist\n"
		print vMessage
		logging.debug(vMessage)	
		
		print(fE.message)
		tb = traceback.format_exc()
		logging.debug("Extended Info:\n\t" + tb)
	
	vMessage = "Database Dropped:\t" +  fvDBName + "\n"
	print vMessage
	logging.debug(vMessage)	
	return	
	
	
#Create SDE Connection File
def fCreateSDEConnFile(fvDBName):
	vMessage = "Creating SDE Connection for:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	
	ftSDEConnFile = vWorkingDir + fvDBName + ".sde"
	
	if os.path.exists(ftSDEConnFile):		
		print "Removing " + fvDBName + ".sde"
		os.remove(ftSDEConnFile)
	else:
		print "Creating " + fvDBName + ".sde"

	arcpy.CreateArcSDEConnectionFile_management(vWorkingDir, fvDBName + ".sde", "127.0.0.1", "sde:postgresql:127.0.0.1", fvDBName, "DATABASE_AUTH", "sde", vSDEPW,"SAVE_USERNAME","sde.DEFAULT","SAVE_VERSION")
			
	global vSDEDBNameTarget	
	sdeConnFile = vWorkingDir + fvDBName + ".sde"
	
	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created SDE Connection for:\t" +  fvDBName + "\n"
	print vMessage
	logging.debug(vMessage)	
	return	
	
	
#Enable Enterprise GeoDatabase
def fEnableEntGDB(fvDBName):	
	global varcLicFilePath
	global vWorkingDir
	vSDEConnFile = vWorkingDir + fvDBName + ".sde"
	vMessage = "Enabling SDE on Database:\t" + fvDBName 
	fSDEWorkSpaceRelease()
	
	print vMessage
	logging.debug(vMessage)	
	
	arcpy.EnableEnterpriseGeodatabase_management(vSDEConnFile,varcLicFilePath)	

	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	vMessage = "Enabled SDE on Database:\t" + vSDEDBNameTarget + "\n"
	print vMessage
	logging.debug(vMessage)	
	return	
	
	
def fDisconnectUsers():

	global vSDEDBNameSource
	global vSDEDBNameTarget
	global vWorkingDir
	SDEConnFile1 = vWorkingDir + vSDEDBNameSource	
	SDEConnFile2 = vWorkingDir + vSDEDBNameTarget
	
	print "Disconnecting from:\t" + SDEConnFile1
	try:
		arcpy.DisconnectUser(SDEConnFile1,"ALL")
	except:
		print SDEConnFile1 + " does not exist or is not a valid SDE"
		
		
	print "Disconnecting from:\t" + SDEConnFile2
	arcpy.DisconnectUser(SDEConnFile2,"ALL")
	fSDEWorkSpaceRelease()
	
	return
	
	
def fSDEDBTune(fvDBName):
	global vPostgresPW
	global vSDEPW
	vMessage = "Setting Spatial Storage for:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)
	#sdedbtune -o alter -k DEFAULTS -P GEOMETRY_STORAGE -v PG_GEOMETRY -s 192.168.11.22 -D live -u sde -p AppXN1 -i sde:postgresql:192.168.11.22
	vOSExecute = "sdedbtune -o alter -k DEFAULTS -P GEOMETRY_STORAGE -v PG_GEOMETRY -s 127.0.0.1 -D " + fvDBName + " -u sde -p " + vSDEPW + " -i sde:postgresql:127.0.0.1 -N"
	print "Executing:\t" + vOSExecute
	os.system(vOSExecute)	
	
	
	vMessage = "Spatial Storage Set for:\t" +  fvDBName + "\n\n"
	print vMessage
	logging.debug(vMessage)
	return

	
#Releasing Workspace/Locks	
def fSDEWorkSpaceRelease():		
	arcpy.env.workspace = ""
	arcpy.ClearWorkspaceCache_management()
	vMessage = "Workspace Release"
	print vMessage
	logging.debug(vMessage)
	return
	
	
#Set FeatureClass as Versioned	
def	fRegisterAsVersionedFC():
	fSDEWorkSpaceRelease()
	logging.debug("Starting Batch Projection Module")
	print "Starting Batch Projection Module"
	global vSDEDBNameSource 
	global vWorkingDir
	global vCoordinateSystem

	sdeConnFile1 = vWorkingDir +  vSDEDBNameSource + ".sde"
	
	arcpy.env.workspace = sdeConnFile1
	vLayers = arcpy.ListFeatureClasses() + arcpy.ListDatasets()
	
	logging.debug("Starting Versioning Features")
	print "Starting Versioning Features"
	
	for x in range(0,len(vLayers)):
		
		if arcpy.Describe(vLayers[x]).isVersioned == False:
			print "Registering Version for:\t" + vLayers[x]
			arcpy.RegisterAsVersioned_management(vLayers[x])
			logging.debug("ESRI Message:\n\t" + arcpy.GetMessages())
			print str(arcpy.GetMessages()) + "\n"
		else:
			print "\tIs Versioned\t" + vLayers[x]  
			logging.debug("\tIs Versioned\t" + vLayers[x] )
	
	vMessage = "\n\tLayer Versioning Complete\n\n"
	print vMessage
	logging.debug(vMessage)
	fSDEWorkSpaceRelease()
	return

	
#Installing DB Link	
def fDBLinkInstall(fvDBName):
	vMessage = "Installing DBLink:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	fAlterPGPass(fvDBName)
	

	fSDEWorkSpaceRelease()
	if os.path.exists(os.environ["ProgramFiles"] + "/AppXN/SpatialRouter/DB Setup Scripts/"):
		vDBLinkPath = os.environ["ProgramFiles"] + "/AppXN/SpatialRouter/DB Setup Scripts/dblink.sql"
		os.system("psql -h 127.0.0.1 -U postgres -w -f " + vDBLinkPath + " " +  fvDBName)		
		vMessage = "DBLink Install Complete:\t" +  fvDBName + "\n"
		
	elif  os.path.exists(os.environ["ProgramFiles(x86)"] + "/AppXN/SpatialRouter/DB Setup Scripts/"):	
		vDBLinkPath = os.environ["ProgramFiles(x86)"] + "/AppXN/SpatialRouter/DB Setup Scripts/dblink.sql"
		os.system("psql -h 127.0.0.1 -U postgres -w -f " + vDBLinkPath + " " +  fvDBName)		
		vMessage = "DBLink Install Complete:\t" +  fvDBName + "\n"
		
	else:
		vMessage = "Could not locate DBLink.sql"


	print vMessage
	logging.debug(vMessage)	
	
	return	


def fGISDBSetup(fvDBName):
	vMessage = "Installing GISDBSetup.sql:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	fAlterPGPass(fvDBName)
	
	
	fSDEWorkSpaceRelease()
	if os.path.exists(os.environ["ProgramFiles"] + "/AppXN/SpatialRouter/DB Setup Scripts/"):
		vDBLinkPath = os.environ["ProgramFiles"] + "/AppXN/SpatialRouter/DB Setup Scripts/gisdbsetup.sql"
		os.system("psql -h 127.0.0.1 -U postgres -w -f " + vDBLinkPath + " " +  fvDBName)		
		vMessage = "GIS DB Setup Install Complete:\t" +  fvDBName + "\n\n"
		
	elif  os.path.exists(os.environ["ProgramFiles(x86)"] + "/AppXN/SpatialRouter/DB Setup Scripts/"):	
		vDBLinkPath = os.environ["ProgramFiles(x86)"] + "/AppXN/SpatialRouter/DB Setup Scripts/gisdbsetup.sql"
		os.system("psql -h 127.0.0.1 -U postgres -w -f " + vDBLinkPath + " " +  fvDBName)		
		vMessage = "GIS DB Setup Install Complete:\t" +  fvDBName + "\n\n"
		
	else:
		vMessage = "Could not locate gisdbsetup.sql"


	print vMessage
	logging.debug(vMessage)	
	
		
	return		

	
#Create Replica	
def fCreateReplica(fvReplicaName):
	global gvMessage
	try:
		vMessage = "Creating Replica for:\t" + fvReplicaName + "\n"
		print vMessage
		logging.debug(vMessage)	
		
		global vSDEDBNameSource
		global vSDEDBNameTarget
		global vWorkingDir
		SDEConnFile1 = vWorkingDir + vSDEDBNameSource + ".sde"
		SDEConnFile2 = vWorkingDir + vSDEDBNameTarget + ".sde"

		
		print "Getting List of Tables"
		logging.debug("Getting List of Tables")
		
		
		

	#Start Importing  GIS	
		print "Setting workspace to:\t" + SDEConnFile1
		arcpy.env.workspace = SDEConnFile1
		
		SDEMapLayers = []
		
		SDEDataSets = arcpy.ListDatasets()
		SDEFeatures = arcpy.ListFeatureClasses()

		
		print "\n\nProcessing Feature Classes in Root"
		print "Number of Features: ", len(SDEFeatures)
		print "List of Features: ", SDEFeatures
		
		if len(SDEFeatures) > 0:
			
			for x in range(0,len(SDEFeatures)):
				if "SDE." in SDEFeatures[x]:
					SDEMapLayers.append(SDEFeatures[x]) #[SDEFeatures[x].index("SDE.") + 4:])
				else:
					SDEMapLayers.append(SDEFeatures[x])
			print "Added: ",SDEMapLayers[-1]
		else:
			print "There are no feature Classes in the Root"
			
		
		arcpy.env.workspace = ""
		arcpy.ClearWorkspaceCache_management()
		

		print "\n\nProcessing Feature Datasets"
		print "Number of Datasets: ", len(SDEDataSets)
		print "List of Datasets: ", SDEDataSets
		
		if len(SDEDataSets) > 0:
			
			for x in range(0,len(SDEDataSets)):
				tFeatureName = SDEDataSets[x]
				
				arcpy.env.workspace = SDEConnFile1 + "/" + tFeatureName
				print "Feature:\t" + tFeatureName
				SDEFeatures = arcpy.ListFeatureClasses()
				arcpy.env.workspace = ""
				arcpy.ClearWorkspaceCache_management()
				for y in range(0,len(SDEFeatures)):
					SDEMapLayers.append(tFeatureName + "/" + SDEFeatures[y][SDEFeatures[y].lower().index("sde.") + 4:])
					print "Feature:\t" + tFeatureName + "/" + SDEFeatures[y][SDEFeatures[y].lower().index("sde.") + 4:]
					
		else:
			print "There are no Feature Datasets"
	# End Importing  GIS	
		
		
		#vLayers = ""
		
		for x in range(0,len(SDEMapLayers)):
			if x == 0:
				vLayers = "'" + SDEConnFile1 + "/" + str(SDEMapLayers[x]) + "'"
				print  "'" + SDEConnFile1 + "/" +  str(SDEMapLayers[x]) + "'"
			else:
				vLayers = vLayers + ";'" + SDEConnFile1 + "/" +  str(SDEMapLayers[x]) + "'"
				print ";'" + SDEConnFile1 + "/" +  str(SDEMapLayers[x]) + "'"
		vLayersMsg = "\nProcessing Layers:\n\t" + str(vLayers).replace(";",";\n\t") + "\n\n"
		logging.debug(vLayersMsg)
		
		print vLayersMsg

		
		print "\n\nStarting ESRI Replication\n--------------------------------------\n" + fvReplicaName + "\n"
		arcpy.CreateReplica_management(vLayers, "ONE_WAY_REPLICA",SDEConnFile2, fvReplicaName, "SIMPLE", "PARENT_DATA_SENDER", "USE_DEFAULTS", "DO_NOT_REUSE", "GET_RELATED", "", "DO_NOT_USE_ARCHIVING")
		
		logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
		
		fSDEWorkSpaceRelease()
		
		vMessage = "Replica Created for:\t" + fvReplicaName + "\n"
		print vMessage
		logging.debug(vMessage)
		
	except Exception, fE:
	
		print(fE.message)
		tb = traceback.format_exc()
		logging.debug("Extended Info:\n\t" + tb)
		gvMessage = "Replication Retry Required\n\t" + tb
		print gvMessage
	
	return 
	
	
def fPGDump(fvDBName):	
	vMessage = "Creating Schema Dump for:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	
	
	global vPGDumpFile
	global vWorkingDir
	SDEConnFile1 = vWorkingDir + fvDBName + ".sde"
			

#Start Importing  GIS	
	print "Setting workspace to:\t" + SDEConnFile1
	arcpy.env.workspace = SDEConnFile1
	
	SDEMapLayers = []
	
	SDEDataSets = arcpy.ListDatasets()
	SDEFeatures = arcpy.ListFeatureClasses()

	
	print "\n\nProcessing Feature Classes in Root"
	print "Number of Features: ", len(SDEFeatures)
	print "List of Features: ", SDEFeatures
	
	if len(SDEFeatures) > 0:
		
		for x in range(0,len(SDEFeatures)):
			if "SDE." in SDEFeatures[x]:
				SDEMapLayers.append(SDEFeatures[x]) #[SDEFeatures[x].index("SDE.") + 4:])
			else:
				SDEMapLayers.append(SDEFeatures[x])
		print "Added: ",SDEMapLayers[-1]
	else:
		print "There are no feature Classes in the Root"
		
	
	arcpy.env.workspace = ""
	arcpy.ClearWorkspaceCache_management()
	

	print "\n\nProcessing Feature Datasets"
	print "Number of Datasets: ", len(SDEDataSets)
	print "List of Datasets: ", SDEDataSets
	
	if len(SDEDataSets) > 0:
		
		for x in range(0,len(SDEDataSets)):
			tFeatureName = SDEDataSets[x]
			
			arcpy.env.workspace = SDEConnFile1 + "/" + tFeatureName
			print "Feature:\t" + tFeatureName
			SDEFeatures = arcpy.ListFeatureClasses()
			arcpy.env.workspace = ""
			arcpy.ClearWorkspaceCache_management()
			for y in range(0,len(SDEFeatures)):
				SDEMapLayers.append(SDEFeatures[y][SDEFeatures[y].lower().index("sde.") + 4:])
				print "Feature:\t" + tFeatureName + "/" + SDEFeatures[y][SDEFeatures[y].lower().index("sde.") + 4:]
				
	else:
		print "There are no Feature Datasets"
# End Importing  GIS	
	
	apgDumpTables = []
	for x in range(0,len(SDEMapLayers)):
		vMessage =  "Table Parsing:\t" + SDEMapLayers[x].replace(".sde.","").replace(fvDBName,"")
		print vMessage
		logging.debug(vMessage)
		apgDumpTables.append(SDEMapLayers[x].replace(".sde.","").replace(fvDBName,""))
	
	strTables = ""
	for x in range(0,len(apgDumpTables)):
		strTables = strTables + " -t " + apgDumpTables[x] + " "

	fSDEWorkSpaceRelease()
	fAlterPGPass(fvDBName)
	vPGDumpFile = vWorkingDir + fvDBName + "_rollback_dump.backup"
	bPGDumpCommand = "pg_dump -s" + strTables + " -U postgres -w -h 127.0.0.1 -f \"" + vPGDumpFile + "\" " +  fvDBName
	print bPGDumpCommand
	
	os.system(bPGDumpCommand)	
	
	print "\n\nAdding Schema to PGDump Files\n"
	
	vPGSchemaSQL = "CREATE SCHEMA sde AUTHORIZATION sde; \n GRANT ALL ON SCHEMA sde TO sde; \n GRANT USAGE ON SCHEMA sde TO public; \n \n"
	
	vPGDF = open(vPGDumpFile,"r")
	vContent = vPGDF.read()
	vPGDF.close()
	
	vPGDF = open(vPGDumpFile,"r+")
	vPGDF.write(vPGSchemaSQL + vContent)
	vPGDF.close()
	
	vMessage = "PG_Dump Complete for:\t" +  fvDBName + "\n\n"
	print vMessage
	logging.debug(vMessage)
	return

	
def fPGDBRestore(fvDBName):	
	global vPGDumpFile
	
	vPGCmdLine = "psql -h 127.0.0.1 -U postgres -w -h 127.0.0.1 -f \"" + vPGDumpFile + "\" " + fvDBName
	print "Running PSQL Command\n\t" + vPGCmdLine
	os.system(vPGCmdLine)
	return
	
	
def fnColor(fStatus):	
	if fStatus == 1: #Standby;
		os.system("color 0a")
	elif fStatus == 2: # Processing;
		os.system("color 0e")
	elif fStatus == 3: #Error;
		os.system("color 0c")
	
	
#Check if PGAdmin is Running
def fnProcessRunning(fnProcessName):
	s = subprocess.check_output('tasklist', shell=True)
	if fnProcessName.lower() in s.lower():
		fnLogThis("\n\n" + fnProcessName + " is Open\n\tPlease Close PGAdmin before continuing")
		sys.exit()
	else:
		print fnProcessName + " is Closed"
	
	
def fnLogThis(vMessage):
	logging.debug(vMessage)
	print vMessage
		
		
	
	
	
try:
	
	fnColor(2)
	fnProcessRunning("PGAdmin3.exe")
	
	fCreateSDEConnFile(vSDEDBNameSource)
	fRegisterAsVersionedFC()
	
	fAlterPGPass("postgres")
	
	#Set Up Live
	fSDEWorkSpaceRelease()
	fDropDB(vSDEDBNameTarget)
	fAlterPGPass("postgres")
	fCreateDB(vSDEDBNameTarget)
	fCreateSDEConnFile(vSDEDBNameTarget)
	fEnableEntGDB(vSDEDBNameTarget)
	fSDEDBTune(vSDEDBNameTarget)
	
	fResetPGPass()
	
	fCreateReplica(vReplicaName)
	
	fDBLinkInstall(vSDEDBNameSource)
	fDBLinkInstall(vSDEDBNameTarget)
	fGISDBSetup(vSDEDBNameTarget)
	
	

	fPGDump(vSDEDBNameTarget)
	#Set Up Rollback
	fSDEWorkSpaceRelease()	
	fDropDB(vRollbackDB)
	fCreateDB(vRollbackDB)
	fCreateSDEConnFile(vRollbackDB)
	fEnableEntGDB(vRollbackDB)
	fSDEDBTune(vRollbackDB)
	fAlterPGPass(vRollbackDB)
	fPGDBRestore(vRollbackDB)	
	fDBLinkInstall(vRollbackDB)
	
	fResetPGPass()
	fnColor(1)
	
except Exception, e:
	gvMessage = "FAIL"
	fnColor(3)
	print(e.message)
	print arcpy.GetMessages()
	tb = traceback.format_exc()
	logging.debug(tb)
	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")

finally:
	"""
	if gvMessage == "FAIL":
		raise Exception("Script Failure")
	"""
		
	logging.debug(vLoggingSegmenter)		
	logging.shutdown()

	


