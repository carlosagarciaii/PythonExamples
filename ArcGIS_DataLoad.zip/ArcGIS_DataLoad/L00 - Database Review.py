# Author: 	Carlos Garcia II
#	
#	This sscript is designed to batch project from one SDE
#	to another while removing Z & M Values.




import os,sys,arcpy,traceback,logging, datetime


global gvSDEDBName 
global gvPostgresPW
global gvSDEPW
global varcLicFilePath

try:
	gvSDEDBName = sys.argv[1]
except:
	print "Arguments not Provided. Use:\n\t" + os.path.basename(sys.argv[0]) + " [DB Name]"
	os.system("color 0d")
	sys.exit()

# Configuration

gvPostgresPW = "AppXNUN"
gvSDEPW = "AppXNPW"



#End Configuration




#Global Variables
global vWorkingDir
vWorkingDir = str(os.path.dirname(os.path.abspath(__file__)) + "/WorkingDir/").replace("\\","/")
global gvMessage
gvMessage = "" 
global gaFeaturePath
gaFeaturePath = []
global gaFeatureFieldCount
gaFeatureFieldCount = []
global gaFeatureDateFields
gaFeatureDateFields = []
global gaFeatureGUIDFields
gaFeatureGUIDFields = []


#Create Working Directory
if not os.path.exists(vWorkingDir):
	print "Output Directory Does Not Exist"
	os.makedirs(vWorkingDir)
else:
	print "Output Directory Exists"


#Logging Setup
logging.basicConfig(filename=vWorkingDir + os.path.basename(__file__) + '_diagnostic.log', format='%(asctime)s %(message)s', level=logging.DEBUG)
vLoggingSegmenter = "Closing Log\n\n________________________________________________________\n________________________________________________________\n\n"


def fnColor(fStatus):	
	print "\n\n"

	if fStatus == 1: #Standby;
		os.system("color 0a")
	elif fStatus == 2: # Processing;
		os.system("color 0e")
	elif fStatus == 3: #Error;
		os.system("color 0c")
	return
	
	
def fGetLayers(fvDBName):	
	global gaFeaturePath
	global vWorkingDir
	vSDEConnFile = vWorkingDir + fvDBName + ".sde"
	
	aFeatureDataSets = []
	aFeatureClasses = []
	
	
	fSDEWorkSpaceRelease()
	arcpy.env.workspace = vSDEConnFile
	
	aFeatureDataSets = arcpy.ListDatasets()
	aFeatureClasses = arcpy.ListFeatureClasses()
	logging.debug("\n\t" + str(aFeatureDataSets) + "\n\t" + str(aFeatureClasses))
	
	
	
#Pulling Feature Classes and formatting for 
	if len(aFeatureClasses) > 0:
		for x in range(0,len(aFeatureClasses)):
			tFeature = vSDEConnFile + "/" + aFeatureClasses[x] 
			gaFeaturePath.append(tFeature)
			
#Pulling Feature Datasets	
	if len(aFeatureDataSets) > 0:
		for x in range(0,len(aFeatureDataSets)):
			
			print "Finding Layers in:\t" + vSDEConnFile + "/" + aFeatureDataSets[x]
			
			fSDEWorkSpaceRelease()
			arcpy.env.workspace = vSDEConnFile + "/" + aFeatureDataSets[x]
			
			
			
			aFeatureClasses = arcpy.ListFeatureClasses()
			for y in range(0,len(aFeatureClasses)):
			
				tFeature = vSDEConnFile + "/" + aFeatureDataSets[x] + "/" + aFeatureClasses[y] 
				gaFeaturePath.append(tFeature)
				
	tLayersDetected  = "Layers Detected:\n\t"
	for x in range(0,len(gaFeaturePath)):
		tLayersDetected = tLayersDetected + gaFeaturePath[x] + "\n\t"
	
	vMessage = tLayersDetected
	print vMessage
	logging.debug(vMessage)
	return
		
		
def fCountFields():
	global gaFeatureFieldCount
	for x in range(0,len(gaFeaturePath)):
		gaFeatureFieldCount.append("Field Count:\t" + str(len(gaFeaturePath[x])))
		print "\nCounting Fields in:\n\t " +  str(gaFeaturePath[x]).replace(vWorkingDir,"") + "\n\t" + str(gaFeatureFieldCount[-1])
	return
	
	
def fDetectDateFields():
	global gaFeatureDateFields

	for x in range(0,len(gaFeaturePath)):	
		vDateFieldList = ""
		for f in arcpy.ListFields(gaFeaturePath[x]):
			
			#Delete Date Fields
			if (f.type == 'Date'):
				vDateFieldList = vDateFieldList  + str(f.name) + ","
				
		gaFeatureDateFields.append(vDateFieldList[:-1])
		print gaFeatureDateFields[-1]
		
	return

	
def fDetectGlobalIDField():
	global gaFeatureGUIDFields
	
	for x in range(0,len(gaFeaturePath)):
		
		vDateGlobalIDList = ""
		for f in arcpy.ListFields(gaFeaturePath[x]):
			
			if (f.type == 'SmallInteger' and f.length == 38) or (f.type == 'Guid'):
				vDateGlobalIDList = vDateGlobalIDList + str(f.name)  + ","

		gaFeatureGUIDFields.append(vDateGlobalIDList[:-1])
		print gaFeatureGUIDFields[-1]
		
		
	return

	
def fResults():
	
	fCountFields()
	fDetectDateFields()
	fDetectGlobalIDField()
	
	
	vResult = "\n\nResults:\n"
	
	for x in range(0,len(gaFeaturePath)):
		
		vResult = vResult + str(
					"\tFeature:\t" + gaFeaturePath[x].replace(vWorkingDir,"") + "\n\t" + 
					"\tFull Path:\t\t" + gaFeaturePath[x]  + "\n\t" + 
					"\tGlobalID Fields:\t\"" + gaFeatureGUIDFields[x].replace("\t","\t\t")  + "\"\n\t" + 
					"\tDate Fields:\t\t\"" + gaFeatureDateFields[x].replace("\t","\t\t") + "\"\n\t" + 
					str(gaFeatureFieldCount[x]).replace("\t","\t\t") + "\n\t\n\n"
					)
					
		
		
	logging.debug(vResult)	
	
	print "Results have been exported to the Working Directory."
	
	f = open(vWorkingDir + "Results.csv","w+")
	f.write(vResult.replace("\t",",").replace(",,",","))
	f.close()
	
		
def fSDEWorkSpaceRelease():		
	arcpy.env.workspace = ""
	arcpy.ClearWorkspaceCache_management()
	vMessage = "---- Workspace Release ----"
	print vMessage
	logging.debug(vMessage)
	return

	
def fCreateSDEConnFile(fvDBName):
	vMessage = "Creating SDE Connection for:\t" +  fvDBName
	print vMessage
	logging.debug(vMessage)	
	
	ftSDEConnFile = vWorkingDir + fvDBName + ".sde"
	
	if os.path.exists(ftSDEConnFile):		
		print "Removing " + fvDBName + ".sde"
		os.remove(ftSDEConnFile)
	else:
		print "Creating " + fvDBName + ".sde"

	arcpy.CreateArcSDEConnectionFile_management(vWorkingDir, fvDBName + ".sde", "localhost", "sde:postgresql:localhost", fvDBName, "DATABASE_AUTH", "sde", gvSDEPW,"SAVE_USERNAME","sde.DEFAULT","SAVE_VERSION")
			
	global vSDEDBNameTarget	
	sdeConnFile = vWorkingDir + fvDBName + ".sde"
	
	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
	
	fSDEWorkSpaceRelease()
	
	vMessage = "Created SDE Connection for:\t" +  fvDBName + "\n"
	print vMessage
	logging.debug(vMessage)	
	return	
	


	
try:
	fnColor(2)
	
	fCreateSDEConnFile(gvSDEDBName)
	fGetLayers(gvSDEDBName)
	fResults()
	
	fnColor(1)
	
except Exception, e:
	gvMessage = "FAIL"
	fnColor(3)
	logging.debug("A Failure Has Occurred")
	print(e.message)
	print arcpy.GetMessages()
	tb = traceback.format_exc()
	logging.debug(tb)
	logging.debug("\n\n" + arcpy.GetMessages() + "\n\n")
	
finally:
	logging.debug(vLoggingSegmenter)		
	logging.shutdown()
